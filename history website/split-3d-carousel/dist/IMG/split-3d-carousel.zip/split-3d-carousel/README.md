# Split 3D Carousel

A Pen created on CodePen.io. Original URL: [https://codepen.io/paulnoble/pen/yVyQxv](https://codepen.io/paulnoble/pen/yVyQxv).

A new spin on the carousel pattern with a split panel transition in three dimensions.